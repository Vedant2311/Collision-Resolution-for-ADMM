#include "Application.hpp"
#include <random>
#include "MCL/XForm.hpp"
#include "MCL/ShapeFactory.hpp"
#include<vector>
using namespace admm;
using namespace mcl;
Application app;
int main(int argc, char *argv[]){

	admm::Solver::Settings settings;
	settings.linsolver = 1; // 0 for LDLT, 1 for NCMCGS
	settings.timestep_s = 1.0/24;
	if( settings.parse_args( argc, argv ) ){ return EXIT_SUCCESS; }
	Application app(settings);
	int res = 20;
	std::vector< mcl::TriangleMesh::Ptr > meshes = {
		mcl::factory::make_plane(res, res)
	};

	

	meshes[0]->flags = binding::NOSELFCOLLISION | binding::LINEAR;
	const mcl::XForm<float> xf_up = mcl::xform::make_trans(0.f, .7f, 0.f) * mcl::xform::make_rot(-90.f,mcl::Vec3f(1,0,0)) * mcl::xform::make_scale(.75f,.75f, .75f); //mcl::xform::make_scale(.5f,.5f, .5f); //
	// const mcl::XForm<float> xf_up2 = mcl::xform::make_trans(0.f, 20.f, 0.f);
	meshes[0]->apply_xform( xf_up );

	// Add meshes to the system
	// admm::Lame very_soft_rubber(10000,0.1);
	admm::Lame very_soft_rubber(100,0.1);
	// very_soft_rubber.limit_min = 0.95;
	// very_soft_rubber.limit_max = 1.05;
	very_soft_rubber.limit_min = 0.5;
	very_soft_rubber.limit_max = 1.5;
	
	app.add_dynamic_mesh( meshes[0], very_soft_rubber );

	// Try to init the solver
	if( !app.solver->initialize(settings) ){ return EXIT_FAILURE; }

	int n_d_meshes = app.dynamic_meshes.size();
	for( int i=0; i<n_d_meshes; ++i ){
		app.renderWindow->add_mesh( app.dynamic_meshes[i].surface );
	}
    double sphere_r = 0.35;
    typedef Eigen::Matrix<double,3,1> Vec3;

	
    std::shared_ptr<admm::PassiveCollision> sphere_collider = 
		std::make_shared<admm::Sphere>( admm::Sphere(Vec3(0,0,0), sphere_r) );
		
	// Add a floor renderable
	std::shared_ptr<mcl::TriangleMesh> sphere = mcl::factory::make_sphere(mcl::Vec3f(0.f,0.f,0.f), sphere_r, 1000);
	// sphere->apply_xform( xf_up2 );
	// std::cout<<(*sphere_collider).give_lambda()[0]<<"lambda\n";

	app.add_obstacle( sphere_collider, sphere );
	bool success = app.display();
	if( !success ){ return EXIT_FAILURE; }

	return EXIT_SUCCESS;

}
