// Copyright (c) 2017, University of Minnesota
// 
// ADMM-Elastic Uses the BSD 2-Clause License (http://www.opensource.org/licenses/BSD-2-Clause)
// Redistribution and use in source and binary forms, with or without modification, are
// permitted provided that the following conditions are met:
// 1. Redistributions of source code must retain the above copyright notice, this list of
//    conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice, this list
//    of conditions and the following disclaimer in the documentation and/or other materials
//    provided with the distribution.
// THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE UNIVERSITY OF MINNESOTA, DULUTH OR CONTRIBUTORS BE 
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
// OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
// IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
// OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "Solver.hpp"
#include "MCL/MicroTimer.hpp"
#include <fstream>
#include <unordered_set>
#include "NodalMultiColorGS.hpp"
#include "UzawaCG.hpp"
#include <unordered_map>
#include <iostream>
using namespace admm;
using namespace Eigen;

Solver::Solver() : initialized(false) {
	m_constraints = std::make_shared<ConstraintSet>( ConstraintSet() );
}
typedef Eigen::Matrix<double,Eigen::Dynamic,1> VecX;
typedef Eigen::Matrix<double,3,1> Vec3;
double constraint_function(VecX x){
	double radius = 0.35;
	double x1 = x[0], y1 = x[1], z1 = x[2];
	return (sqrt((x1*x1) + (y1*y1) + (z1*z1)) - radius);
}

VecX gradient_function(VecX x){
	
	VecX value  = VecX::Zero(x.size());
	const int n_threads = omp_get_max_threads();
	#pragma omp parallel for num_threads(n_threads)
	for(int i=0; i < x.size(); i +=3){
		double x1 = x[i], y1 = x[i+1], z1 = x[i+2];
		double val = sqrt((x1*x1) + (y1*y1) + (z1*z1));
		value[i] = x1/val;
		value[i+1] = y1/val;
		value[i+2] = z1/val;
	}

	return value;
}

VecX nearest_surface_point(VecX x, VecX x2, int case_){

	double radius = 0.35;
	Vec3 grad;
	if(case_ == 0) grad = gradient_function(x);
	else if (case_ == 1)grad = x2;
	else grad = x2 - x;
	double l1 = 0, l2 = 0, d = 0;

	for(int i=0; i <3; i ++){
		l1 += x[i]*grad[i];
		l2 += grad[i]*grad[i];
		d += x[i]*x[i];
	}
	
	d -= radius*radius;
	double k = (-l1 + sqrt(l1*l1 - l2*d))/l2;
	return x + k*grad;
}

VecX manual_0 (VecX x){
	const int n_threads = omp_get_max_threads();
	#pragma omp parallel for num_threads(n_threads)
	for(int i=0; i <x.size(); i += 3){
		double x1 = x[i], y1 = x[i+1], z1 = x[i+2];
		Vec3 point = Vec3(x1,y1,z1);
		if(constraint_function(point) < 0){
			VecX new_point = nearest_surface_point(point, point, 0);
			x[i] = new_point[0];
			x[i+1] = new_point[1];
			x[i+2] = new_point[2];
		}
	}
	return x;
}

void manual_2_1 (double dt, VecX x0, VecX &x, VecX &lambda0, VecX masses){
	const int n_threads = omp_get_max_threads();
	#pragma omp parallel for num_threads(n_threads)
	for(int i=0; i <x.size(); i += 3){
		Vec3 point = Vec3(x(i), x(i+1), x(i+2)), new_point = Vec3::Zero(3), point0 = Vec3(x0(i), x0(i+1), x0(i+2));
		double cf_point = constraint_function(point);
		if(cf_point >= 0 && lambda0[i/3] == 0) continue;
		new_point = point - dt * (cf_point >= 0) * lambda0[i/3] * gradient_function(point0)/ masses[i];
		if(constraint_function(new_point) >= 0){
			lambda0[i/3] = 0;
			for(int j=0; j <3; j ++) x[i+j] = new_point[j]; 
			continue;
		}
		if(cf_point >= 0){
			new_point = nearest_surface_point(new_point, point, 2);
			for(int j=0; j <3; j ++) x[i+j] = new_point[j];
			double norm_disp = 0;
			// #pragma omp parallel for num_threads(n_threads)
			for(int j=0; j <3; j ++) norm_disp += (new_point[j] - point[j])*(new_point[j] - point[j]);
			norm_disp = sqrt(norm_disp);
			lambda0[i/3] -= masses[i]*norm_disp/dt;
			continue;
		}
		
		new_point = nearest_surface_point(point, gradient_function(point0), 1);
		for(int j=0; j <3; j ++) x[i+j] = new_point[j];
		double norm_disp = 0;
		// #pragma omp parallel for num_threads(n_threads)
		for(int j=0; j <3; j ++) norm_disp += (new_point[j] - point[j])*(new_point[j] - point[j]);
		norm_disp = sqrt(norm_disp);
		lambda0[i/3] += masses[i]*norm_disp/dt;
	}
}
void Solver::step(){

	if( m_settings.verbose > 0 ){
		std::cout << "\nSimulating with dt: " <<
		m_settings.timestep_s << "s..." << std::flush;
	}

	mcl::MicroTimer t;


	// Other const-variable short names and runtime data
	const int dof = m_x.rows();
	const int n_nodes = dof/3;
	const double dt = m_settings.timestep_s;
	const int n_energyterms = energyterms.size();
	const int n_threads = std::min(n_energyterms, omp_get_max_threads());
	m_runtime = RuntimeData(); // reset

	// Take an explicit step to get predicted node positions
	// with simple forces (e.g. wind).
	
	double total_mass = 0;
	for(int i = 0; i < m_masses.size(); i ++){
		total_mass += m_masses(i);
	}

	double factor = 0.25 / (total_mass / (1.5*1.5))
	for(int i = 0; i < m_masses.size(); i ++){
		m_masses(i) *= factor;
	}
	
	const int n_ext_forces = ext_forces.size();
	for( int i=0; i<n_ext_forces; ++i ){ ext_forces[i]->project( dt, m_x, m_v, m_masses ); }

	// Add gravity
	if( std::abs(m_settings.gravity)>0 ){
		for( int i=0; i<n_nodes; ++i ){ m_v[i*3+1] += dt*m_settings.gravity; }
	}
	VecX m_v_org = m_v;
	VecX force_gradient = gradient_function(m_x);

	// for(int obj_num = 0; obj_num < m_constraints->collider->passive_objs.size(); obj_num++){
			
	// 	VecX lambda_cons = (*(m_constraints->collider->passive_objs[obj_num])).give_lambda();
	// 	for(int i=0; i <m_x.size(); i ++){
	// 		m_v[i] += dt*(lambda_cons[i/3])*force_gradient[i]/m_masses(i);
	// 	}
	// }

	std::cout<<" mass " << m_masses[222*3] << " " << m_constraints->collider->passive_objs.size()<<" sizeeeeeeeee\n";
// 	std::ofstream myfile;
// 	myfile.open("outputs.txt", std::ios::app);
// 	myfile << "new_time_step\n";
	
	
	// Storing some of these variables as members can reduce allocation overhead
	// and speed up run time.
	VecX x_bar = m_x + dt * m_v;
	VecX M_xbar = m_masses.asDiagonal() * x_bar;
	VecX M_xbar_org = m_masses.asDiagonal() * (m_x + dt * m_v_org);
	VecX curr_x = x_bar; // Temperorary x used in optimization

	// Initialize ADMM vars

// 	for(int i=0; i <m_x.size(); i ++) myfile << m_x[i]<<" ";
// 	myfile << "\n";
// 	for(int i=0; i <m_x.size(); i ++) myfile << m_masses[i]<<" ";
// 	myfile << "\n";
// 	for(int i=0; i <m_x.size(); i ++) myfile << x_bar[i]<<" ";
// 	myfile << "\n";
// 	VecX lambda_cons = (*(m_constraints->collider->passive_objs[0])).give_lambda();
// 	for(int i=0; i <lambda_cons.size(); i ++) myfile << lambda_cons[i]<<" ";
// 	myfile << "\n";

	VecX curr_z = m_D*m_x;
	VecX curr_u = VecX::Zero( curr_z.rows() );
	VecX solver_termB = VecX::Zero( dof );

	// Passive collisions are detected each GS iteration,
	// so we'll skip them in the global collision detection loop.
	bool detect_passive = m_settings.linsolver!=1;

	// Run a timestep
	int s_i = 0;
	for( ; s_i < m_settings.admm_iters; ++s_i ){ //m_settings.admm_iters

		// Local step
		t.reset();
		#pragma omp parallel for num_threads(n_threads)
		for( int i=0; i<n_energyterms; ++i ){
			energyterms[i]->update( m_D, curr_x, curr_z, curr_u );
		}
		m_runtime.local_ms += t.elapsed_ms();

		// Collision detection, which also updates the BVHs and stuff
		t.reset();
		m_constraints->collider->clear_hits();
		m_constraints->collider->detect( surface_inds, curr_x, detect_passive );
		m_runtime.collision_ms += t.elapsed_ms();

		// Global step
		t.reset();
		solver_termB.noalias() = M_xbar + solver_Dt_Wt_W * ( curr_z - curr_u );
		m_runtime.inner_iters += m_linsolver->solve( curr_x, solver_termB );
		
// 		for(int i=0; i <m_x.size(); i ++) myfile << curr_x[i]<<" ";
// 		myfile << " admm\n";
// 		for(int i=0; i <m_x.size(); i ++) myfile << m_v[i]<<" ";
// 		myfile << " admm\n";
		
		for(int obj_num = 0; obj_num < m_constraints->collider->passive_objs.size(); obj_num++){
			
			VecX lambda_cons = (*(m_constraints->collider->passive_objs[obj_num])).give_lambda();
			if(s_i == 0) lambda_cons*= 0;
			manual_2_1 (dt*dt, m_x, curr_x, lambda_cons, m_masses);
			(*(m_constraints->collider->passive_objs[obj_num])).set_lambda(lambda_cons);
			#pragma omp parallel for num_threads(n_threads)
			for(int i=0; i <m_x.size(); i ++){
				m_v[i] = m_v_org[i] + dt*(lambda_cons[i/3])*force_gradient[i]/m_masses(i);
			}
			x_bar = m_x + dt * m_v;
			M_xbar = m_masses.asDiagonal() * x_bar;	
		}


// 		for(int i=0; i <m_x.size(); i ++) myfile << curr_x[i]<<" ";
// 		myfile << " manual\n";
// 		for(int i=0; i <m_x.size(); i ++) myfile << x_bar[i]<<" ";
// 		myfile << " manual\n";
// 		VecX lambda_cons = (*(m_constraints->collider->passive_objs[0])).give_lambda();
// 		for(int i=0; i <lambda_cons.size(); i ++) myfile << lambda_cons[i]<<" ";
// 		myfile << " manual\n";
		
		m_runtime.global_ms += t.elapsed_ms();

	} // end solver loop

	// Computing new velocity and setting the new state
	m_v.noalias() = ( curr_x - m_x ) * ( 1.0 / dt );
	m_x = curr_x;
// 	myfile.close();
	// Output run time
	if( m_settings.verbose > 0 ){ m_runtime.print(m_settings); }
} // end timestep iteration


void Solver::set_pins( const std::vector<int> &inds, const std::vector<Vec3> &points ){

	int n_pins = inds.size();
	const int dof = m_x.rows();
	bool pin_in_place = (int)points.size() != n_pins;
	if( (dof == 0 && pin_in_place) || (pin_in_place && points.size() > 0) ){
		throw std::runtime_error("**Solver::set_pins Error: Bad input.");
	}

	m_constraints->pins.clear();
	for( int i=0; i<n_pins; ++i ){
		int idx = inds[i];
		if( pin_in_place ){
			m_constraints->pins[idx] = m_x.segment<3>(idx*3);
		} else {
			m_constraints->pins[idx] = points[i];
		}
	}

	// If we're using energy based hard constraints, the pin locations may change
	// but which vertex is pinned may NOT change (aside from setting them to
	// active or inactive). So we need to do some extra work here.
	if( initialized && (m_settings.linsolver==0 || m_settings.linsolver==2) ){

		// Set all pins inactive, then update to active if they are set
		std::unordered_map<int, std::shared_ptr<SpringPin> >::iterator pIter = m_pin_energies.begin();
		for( ; pIter != m_pin_energies.end(); ++pIter ){
			pIter->second->set_active(false);
		}

		// Update pin locations/active
		for( int i=0; i<n_pins; ++i ){
			int idx = inds[i];
			pIter = m_pin_energies.find(idx);
			if( pIter == m_pin_energies.end() ){
				std::stringstream err;
				err << "**Solver::set_pins Error: Constraint for " << idx << " not found.\n";
				throw std::runtime_error(err.str().c_str());
			}
			pIter->second->set_active(true);
			pIter->second->set_pin( m_constraints->pins[idx] );
		}

	} // end set energy-based pins
}

void Solver::add_obstacle( std::shared_ptr<PassiveCollision> obj ){
	m_constraints->collider->add_passive_obj(obj);
}

void Solver::add_dynamic_collider( std::shared_ptr<DynamicCollision> obj ){
	m_constraints->collider->add_dynamic_obj(obj);
}

bool Solver::initialize( const Settings &settings_ ){
	using namespace Eigen;
	m_settings = settings_;

	mcl::MicroTimer t;
	const int dof = m_x.rows();
	if( m_settings.verbose > 0 ){ std::cout << "Solver::initialize: " << std::endl; }

	if( m_settings.timestep_s <= 0.0 ){
		std::cerr << "\n**Solver Error: timestep set to " << m_settings.timestep_s <<
			"s, changing to 1/24s." << std::endl;
		m_settings.timestep_s = 1.0/24.0;
	}
	if( !( m_masses.rows()==dof && dof>=3 ) ){
		std::cerr << "\n**Solver Error: Problem with node data!" << std::endl;
		return false;
	}
	if( m_v.rows() != dof ){ m_v.resize(dof); }

	// Clear previous runtime stuff settings
	m_v.setZero();

	// If we want energy-based constraints, set them up now.
	if( m_settings.linsolver==0 || m_settings.linsolver==2){
		std::unordered_map<int,Vec3>::iterator pinIter = m_constraints->pins.begin();
		for( ; pinIter != m_constraints->pins.end(); ++pinIter ){
			m_pin_energies[ pinIter->first ] = std::make_shared<SpringPin>( SpringPin(pinIter->first,pinIter->second) );
			energyterms.emplace_back( m_pin_energies[ pinIter->first ] );			
		}
	} // end create energy based hard constraints

	// Set up the selector matrix (D) and weight (W) matrix
	std::vector<Eigen::Triplet<double> > triplets;
	std::vector<double> weights;
	int n_energyterms = energyterms.size();
	for(int i = 0; i < n_energyterms; ++i){
		energyterms[i]->get_reduction( triplets, weights );
	}

	// Create the Selector+Reduction matrix
	m_W_diag = Eigen::Map<VecX>(&weights[0], weights.size());
	int n_D_rows = weights.size();
	m_D.resize( n_D_rows, dof );
	m_D.setZero();
	m_D.setFromTriplets( triplets.begin(), triplets.end() );
	m_Dt = m_D.transpose();

	// Compute mass matrix
	SparseMat M( dof, dof );
	Eigen::VectorXi nnz = Eigen::VectorXi::Ones( dof ); // non zeros per column
	M.reserve(nnz);
	for( int i=0; i<dof; ++i ){ M.coeffRef(i,i) = m_masses[i]; }

	// Set global matrices
	SparseMat W( n_D_rows, n_D_rows );
	W.reserve(n_D_rows);
	for( int i=0; i<n_D_rows; ++i ){ W.coeffRef(i,i) = m_W_diag[i]; }
	const double dt2 = (m_settings.timestep_s*m_settings.timestep_s);
	solver_Dt_Wt_W = dt2 * m_Dt * W * W;
	solver_termA = M + SparseMat(solver_Dt_Wt_W * m_D);

	// Set up the linear solver
	switch (m_settings.linsolver){
		default: {
			m_linsolver = std::make_shared<LDLTSolver>( LDLTSolver() );
		} break;
		case 1: {
			m_linsolver = std::make_shared<NodalMultiColorGS>( NodalMultiColorGS(m_constraints) );
			m_constraints->constraint_w = m_W_diag.maxCoeff()*3.0;
		} break;
		case 2: {
			m_linsolver = std::make_shared<UzawaCG>( UzawaCG(m_constraints) );
			m_constraints->constraint_w = 1.0;
		} break;
	}

	// If we haven't set a global solver, make one:
	if( !m_linsolver ){ throw std::runtime_error("What happened to the global solver?"); }
	if( m_settings.constraint_w > 0.0 ){ m_constraints->constraint_w = m_settings.constraint_w; }
	m_linsolver->update_system( solver_termA );

	// Make sure they don't have any collision obstacles
	// if( m_settings.linsolver==0 ){
	// 	if( m_constraints->collider->passive_objs.size() > 0 ||
	// 		m_constraints->collider->dynamic_objs.size() > 0 ){
	// 		throw std::runtime_error("**Solver::add_obstacle Error: No collisions with LDLT solver");
	// 	}
	// }

	// All done
	if( m_settings.verbose >= 1 ){ printf("%d nodes, %d energy terms\n", (int)m_x.size()/3, (int)energyterms.size() ); }
	initialized = true;
	return true;

} // end init


void Solver::save_matrix( const std::string &filename ){

	std::cout << "Saving matrix (" << solver_termA.rows() << "x" <<
		solver_termA.cols() << ") to " << filename << std::endl;
	std::ofstream(filename.c_str()) << solver_termA;
}


template<typename T> void myclamp( T &val, T min, T max ){ if( val < min ){ val = min; } if( val > max ){ val = max; } }
bool Solver::Settings::parse_args( int argc, char **argv ){

	// Check args with params
	for( int i=1; i<argc-1; ++i ){
		std::string arg( argv[i] );
		std::stringstream val( argv[i+1] );
		if( arg == "-help" || arg == "--help" || arg == "-h" ){ help(); return true; }
		else if( arg == "-dt" ){ val >> timestep_s; }
		else if( arg == "-v" ){ val >> verbose; }	
		else if( arg == "-it" ){ val >> admm_iters; }
		else if( arg == "-g" ){ val >> gravity; }
		else if( arg == "-ls" ){ val >> linsolver; }
		else if( arg == "-ck" ){ val >> constraint_w; }
	}

	// Check if last arg is one of our no-param args
	std::string arg( argv[argc-1] );
	if( arg == "-help" || arg == "--help" || arg == "-h" ){ help(); return true; }

	return false;

} // end parse settings args

void Solver::Settings::help(){
	std::stringstream ss;
	ss << "\n==========================================\nArgs:\n" <<
		"\t-dt: time step (s)\n" <<
		"\t-v: verbosity (higher -> show more)\n" <<
		"\t-it: # admm iters\n" <<
		"\t-g: gravity (m/s^2)\n" <<
		"\t-ls: linear solver (0=LDLT, 1=NCMCGS, 2=UzawaCG) \n" <<
		"\t-ck: constraint weights (-1 = auto) \n" <<
	"==========================================\n";
	printf( "%s", ss.str().c_str() );
}

void Solver::RuntimeData::print( const Settings &settings ){
	std::cout << "\nTotal global step: " << global_ms << "ms";;
	std::cout << "\nTotal local step: " << local_ms << "ms";
	std::cout << "\nTotal collision update: " << collision_ms << "ms";
	std::cout << "\nAvg global step: " << global_ms/double(settings.admm_iters) << "ms";;
	std::cout << "\nAvg local step: " << local_ms/double(settings.admm_iters) << "ms";
	std::cout << "\nAvg collision update: " << collision_ms/double(settings.admm_iters) << "ms";
	std::cout << "\nADMM Iters: " << settings.admm_iters;
	std::cout << "\nAvg Inner Iters: " << float(inner_iters) / float(settings.admm_iters);
	std::cout << std::endl;
}
